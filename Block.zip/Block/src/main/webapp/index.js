function patternCheck(){

var batch = document.getElementById("batch").value;
var name = document.getElementById("name").value;

name= name.trim();
var pattern = new RegExp("^SM[A-Z0-9]{6}");

if(!pattern.test(batch)){
	document.getElementById("batchResult").innerHTML = "Batch No. is not valid";
	return false;
}

if(name.length<=3){
	document.getElementById("batchResult").innerHTML = "";
	 document.getElementById("nameResult").innerHTML = "Name is not valid";
	 return false;
}
if(batch.length <8 || batch.length >8){
	 document.getElementById("batchResult").innerHTML = "Batch No. is not valid";
	 return false;
	}

return true;

}
