package com.company;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Product {
	public static ArrayList<Block> blockchain = new ArrayList<>();
	public static String result = "";

	public Product(String batchNo, String name) throws Exception {

		Class.forName("com.mysql.jdbc.Driver");
		Connection myConn;
		Statement mystmt;
		myConn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/fakeProduct", "root", "12345#Ayush");
		ResultSet myRs = null;

		String count = "select count(*) from product";
		int flag = 0;

		mystmt = myConn.createStatement();
		ResultSet row1 = mystmt.executeQuery(count);
		int size = 0;
		row1.next();
		int c = Integer.valueOf(row1.getString(1));
		if (c > 0) {

			String s = "select * from product";
			mystmt = myConn.createStatement();
			row1 = mystmt.executeQuery(s);
			while (row1.next()) {

				blockchain.add(new Block(row1.getString(1), row1.getString(2), row1.getString(3)));
			}

			blockchain.add(new Block(batchNo, name, blockchain.get(blockchain.size() - 1).getHash()));

			size = blockchain.size() - 1;

			mystmt = myConn.createStatement();
			String batchn = "'" + batchNo + "'";
			row1 = mystmt.executeQuery("select batch_no from product where batch_no=" + batchn);

			if (row1.next()) {
				result = "Product Already Exist ";
				flag = 1;
			}

		}

		else {
			blockchain.add(new Block(batchNo, name, "0"));
		}
		if (flag == 0) {
			try {

				String batch = batchNo;
				batch = "'" + batch + "'";
				String hash = blockchain.get(size).getHash();
				hash = "'" + hash + "'";
				String nam = "'" + name + "'";

				String st = "Insert into product(batch_no,name,hashValue) values(" + batch + "," + nam + "," + hash
						+ ")";
				mystmt = myConn.createStatement();
				int row = mystmt.executeUpdate(st);

				result = "Product Added successfully! ";

			} catch (SQLException e) {
				result = "Error Occured";
				e.printStackTrace();
			}

		}
		if (flag == 2) {
			result = "Block Chain Tempered By Someone";
		}
	}

	public static boolean isValid() { // checks if the block network is tampered or not
		Block current, previous;
		for (int i = 1; i < blockchain.size(); i++) {
			current = blockchain.get(i);
			previous = blockchain.get(i - 1);

			if (!current.QRvalue().equals(current.CalculateHash())) {
				System.out.println("Hash not Match");
				return false;
			}

			if (!current.getPreviousHash().equals(previous.getHash())) {
				System.out.println("Previous Hash not Match");
				return false;
			}
		}

		return true;
	}

	public static String result() {
		return result;
	}

}
