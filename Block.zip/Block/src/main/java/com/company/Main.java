package com.company;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Connection myConn;
		Statement mystmt;
		myConn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/fakeProduct", "root", "12345#Ayush");
		ResultSet myRs = null;

		int j = 0;
		try {

			String batch = "102F";
			batch = "'" + batch + "'";
			String hash = "102512gdg4t5466";
			hash = "'" + hash + "'";
			String nam = "'" + "Ayush" + "'";
			String s = "select count(*) from product";
			// String st = "Insert into product(batch_no,name,QRvalue) values(" + batch +
			// "," + nam + "," + hash + ")";
			mystmt = myConn.createStatement();
			ResultSet row = mystmt.executeQuery(s);
			row.next();
			int count = Integer.valueOf(row.getString(1));
			if (count >= 1) {
				System.out.println(row.getString(1));
			} else {
				System.out.println("Ayush");
			}

			j++;

		} catch (SQLException e) {
			// result = "Error Occured";
			e.printStackTrace();
		}

	}
}
