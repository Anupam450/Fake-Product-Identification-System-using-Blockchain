package com.company;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Extract {

	public static String result = "";

	public Extract(String batch) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;

		try {

			con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/fakeProduct", "root", "12345#Ayush");
			st = con.createStatement();
			batch = "'" + batch + "'";
			rs = st.executeQuery("SELECT batch_no, name FROM product WHERE batch_no =" + batch);

			if (rs.next()) {

				String scanHash = rs.getString("batch_no") + "  " + rs.getString("name") + " " + " is Valid";

				result = scanHash;

			} else {
				result = "Not a Valid Product";
			}

		} catch (SQLException e) {
			e.printStackTrace();

		}
	}

	public String result() {
		return result;
	}

}
