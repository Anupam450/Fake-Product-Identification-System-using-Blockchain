package com.company;

import java.security.MessageDigest;
//import javax.sql.rowset.serial.SerialStruct;
import java.sql.Date;

public class Block {

	private String hash;
	private String BatchNo; // drug batch number - data field
	private String Name;
	private String previousHash;
	private long time;

	public String getHash() {
		return this.hash;
	}

	public String getName() {
		return this.Name;
	}

	public void setName(String name) {
		this.Name = name;
	}

	public void setHash(String hash) {

		this.hash = hash;
	}

	public String getBatchNo() {

		return this.BatchNo;
	}

	public void setBatchNo(String batchNo) {

		BatchNo = batchNo;
	}

	public void setPreviousHash(String previousHash) {

		this.previousHash = previousHash;
	}

	public long getTime() {

		return time;
	}

	public void setTime(long time) {

		this.time = time;
	}

	public String getPreviousHash() {
		return this.previousHash;
	}

	public Block(String BatchNo, String Name, String previousHash) {
		this.BatchNo = BatchNo;
		this.Name = Name;
		this.previousHash = previousHash;
		this.time = new Date(time).getTime();
		this.hash = CalculateHash();
		// System.out.println(hash);
	}

	public String CalculateHash() { // hash calculated using SHA-256 Algorithm

		String BatchNo = previousHash + time + this.BatchNo;
		MessageDigest digest = null;
		byte[] arr = null;

		try {
			digest = MessageDigest.getInstance("SHA-256");
			arr = digest.digest(BatchNo.getBytes());
		} catch (Exception e) {
			System.out.println("Error");
		}

		StringBuffer buffer = new StringBuffer();

		for (byte b : arr) {
			String hex = Integer.toHexString(0xff & b);

			if (hex.length() == 1)
				buffer.append("0");
			buffer.append(hex);
		}

		return buffer.toString();

	}

	public String QRvalue() {

		String str;
		str = this.hash;
		return str;

	}

}
